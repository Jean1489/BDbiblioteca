package accesoDatos;

import logica.Estudiante;
import logica.Profesor;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DaoProfesor {
    FachadaBD fachada;

    public DaoProfesor(){fachada = new FachadaBD();}

    public int insertarProfesor(Profesor profesor){
        String sql_guardar = "INSERT INTO Profesor (id_profesor, dependencia, titulo_universitario, areas_interes) VALUES( '" + profesor.getIdProfesor() + "', '" +
                profesor.getDependencia() + "','" + profesor.getTitulo() + "','" + profesor.getArea_estudio()  + "')";
        try {
            Connection conn = fachada.openConnection();
            Statement sentencia = conn.createStatement();
            int numFilas = sentencia.executeUpdate(sql_guardar);
            conn.close();
            return numFilas;

        }
        catch (SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null,"El Id ingresado ya existe");
        }
        catch (Exception e) {System.out.println(e);}

        return -1;
    }
    public Profesor consultarProfesor(String idProfesor){
        Profesor teacher = new Profesor();
        String sql_select;
        sql_select = "SELECT dependencia, titulo_universitario, areas_interes FROM Profesor WHERE id_profesor = '" + idProfesor + "'";

        try{
            System.out.println("consultando en la bd");
            Connection conn = fachada.openConnection();
            Statement sentencia = conn.createStatement();
            ResultSet tabla = sentencia.executeQuery(sql_select);

            while (tabla.next()){
                teacher.setDependencia(tabla.getString(1));
                teacher.setTitulo(tabla.getString(2));
                teacher.setArea_estudio(tabla.getString(3));
            }

            conn.close();
            System.out.println("Conexion Cerrada");

        }
        catch(SQLException e){ System.out.println(e); }
        catch(Exception e){ System.out.println(e); }
        return teacher;
    }
    public void modificarProfesor(Profesor profesor, String idProfesor){
        String sql_update = "UPDATE Profesor SET dependencia = '" + profesor.getDependencia() + "', titulo_universitario = '" +
                profesor.getTitulo() + "', areas_interes = '" + profesor.getArea_estudio() + "' WHERE id_profesor = '" +
                idProfesor + "'";
        try{
            Connection conn = fachada.openConnection();
            Statement sentencia = conn.createStatement();
            if (sentencia.executeUpdate(sql_update) > 0) JOptionPane.showMessageDialog(null,"Se actualizó correctamente");
        }
        catch(SQLException e){ System.out.println(e);}
        catch(Exception e){ System.out.println(e);}
    }
    public List<Profesor> listarProfesores(){
        List<Profesor> profesorList = new ArrayList<>();
        PreparedStatement sentencia = null;
        String sql_list = "SELECT * FROM Profesor";

        try{
            Connection conn = fachada.openConnection();
            sentencia = conn.prepareStatement(sql_list);
            ResultSet rs = sentencia.executeQuery();
            while(rs.next()){
                Estudiante student = new Estudiante();
                Profesor teacher = new Profesor();
                teacher.setIdProfesor(rs.getString(1));
                teacher.setDependencia(rs.getString(2));
                teacher.setTitulo(rs.getString(3));
                teacher.setArea_estudio(rs.getString(4));
                profesorList.add(teacher);
            }
        }
        catch(SQLException e){ System.out.println(e); }
        catch(Exception e){ System.out.println(e); }

        return profesorList;
    }
    public void eliminarProfesor(String idProfesor){
        String sql_delete;
        sql_delete = "DELETE FROM Profesor WHERE id_profesor ='" + idProfesor +  "'";

        try{
            Connection conn = fachada.openConnection();
            Statement sentencia = conn.createStatement();
            int filasafectadas = sentencia.executeUpdate(sql_delete);
            if(filasafectadas > 0) JOptionPane.showMessageDialog(null, "El registro se ha eliminado correctamente");
            else {System.out.println("El " + idProfesor + "no existe en la base de datos");}
        }
        catch(SQLException e){ System.out.println(e); }
        catch(Exception e){ System.out.println(e); }
    }
    public void cerrarConexionBD(){
        fachada.closeConection(fachada.getConexion());
    }
}
