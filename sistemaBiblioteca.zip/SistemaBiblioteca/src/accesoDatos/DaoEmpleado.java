package accesoDatos;

import logica.Empleado;
import logica.Estudiante;
import logica.Profesor;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DaoEmpleado {
    FachadaBD fachada;

    public DaoEmpleado(){
        fachada = new FachadaBD();
    }

    public int insertarEmpleado(Empleado empleado){
        String sql_guardar = "INSERT INTO Empleado (id_empleado, nombre_empleado, cargo) VALUES( '" + empleado.getIdEmpleado() + "' , '" + empleado.getNombre() + "' , '" +
                empleado.getCargo() + "')";
        try {
            Connection conn = fachada.openConnection();
            Statement sentencia = conn.createStatement();
            int numFilas = sentencia.executeUpdate(sql_guardar);
            conn.close();
            return numFilas;

        }
        catch (SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null,"El Id ingresado ya existe");
        }
        catch (Exception e) {
            System.out.println(e);}

        return -1;
    }
    public Empleado buscarEmpleado(String idEmpleado){
        Empleado empleado = new Empleado();
        String sql_select;
        sql_select = "SELECT nombre_empleado, cargo FROM Empleado WHERE id_empleado = '" + idEmpleado + "'";

        try{
            System.out.println("consultando en la bd");
            Connection conn = fachada.openConnection();
            Statement sentencia = conn.createStatement();
            ResultSet tabla = sentencia.executeQuery(sql_select);

            while (tabla.next()){
                empleado.setNombre(tabla.getString(1));
                empleado.setCargo(tabla.getString(2));
            }

            conn.close();
            System.out.println("Conexion Cerrada");

        }
        catch(SQLException e){ System.out.println(e); }
        catch(Exception e){ System.out.println(e); }
        return empleado;
    }
    public void modificarEmpleado(Empleado empleado, String idEmpleado){
        String sql_update = "UPDATE Empleado SET nombre_empleado = '" + empleado.getNombre() + "' , cargo = '" + empleado.getCargo() + "' WHERE id_empleado = '" + idEmpleado + "'";
        try{
            Connection conn = fachada.openConnection();
            Statement sentencia = conn.createStatement();
            if (sentencia.executeUpdate(sql_update) > 0) JOptionPane.showMessageDialog(null,"Se actualizó correctamente");
        }
        catch(SQLException e){ System.out.println(e);}
        catch(Exception e){ System.out.println(e);}
    }
    public List listarEmpleados(){
        List<Empleado> empleados = new ArrayList<>();
        PreparedStatement sentencia = null;
        String sql_list = "SELECT * FROM Empleado";

        try{
            Connection conn = fachada.openConnection();
            sentencia = conn.prepareStatement(sql_list);
            ResultSet rs = sentencia.executeQuery();
            while(rs.next()){
                Empleado empleado = new Empleado();
                empleado.setIdEmpleado(rs.getString(1));
                empleado.setNombre(rs.getString(2));
                empleado.setCargo(rs.getString(3));
                empleados.add(empleado);
            }
        }
        catch(SQLException e){ System.out.println(e); }
        catch(Exception e){ System.out.println(e); }

        return empleados;
    }
    public void borrarEmpleado(String idEmpleado){
        String sql_delete;
        sql_delete = "DELETE FROM Empleado WHERE id_empleado ='" + idEmpleado +  "'";

        try{
            Connection conn = fachada.openConnection();
            Statement sentencia = conn.createStatement();
            int filasafectadas = sentencia.executeUpdate(sql_delete);
            if(filasafectadas > 0) JOptionPane.showMessageDialog(null, "El registro se ha eliminado correctamente");
            else {System.out.println("El " + idEmpleado + "no existe en la base de datos");}
        }
        catch(SQLException e){ System.out.println(e); }
        catch(Exception e){ System.out.println(e); }
    }
    public void cerrarConexionBD(){
        fachada.closeConection(fachada.getConexion());
    }
}
