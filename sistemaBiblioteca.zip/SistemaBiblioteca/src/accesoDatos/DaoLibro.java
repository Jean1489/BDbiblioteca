package accesoDatos;

import logica.Libro;
import logica.Usuario;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DaoLibro {
    FachadaBD fachada;

    public DaoLibro(){
        fachada = new FachadaBD();
    }

    public int guardarLibro(Libro libro){
        String sql_guardar;
        sql_guardar = "INSERT INTO Libro (ISBN,titulo_libro,anho_publicacion,idioma_libro,numero_paginas,codigo_editorial) VALUES ('" +
                libro.getISBN() + "', '" + libro.getTituloLibro() + "' , '" + libro.getAnhoPublicacion() + "' , '" + libro.getIdiomaLibro() + "' , '"
                + libro.getNumeroPaginas() + "' , '" + libro.getCodigoEditorial() + "')";
        try {
            Connection conn = fachada.openConnection();
            Statement sentencia = conn.createStatement();
            int numFilas = sentencia.executeUpdate(sql_guardar);
            conn.close();
            return numFilas;

        }
        catch (SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null,"El ID ya existe en la Base de datos");
        }
        catch (Exception e) {System.out.println(e);}

        return -1;
    }
    public Libro consultarLibro(String ISBN){
        Libro libro = new Libro();
        String sql_select;
        sql_select = "SELECT ISBN, titulo_libro, anho_publicacion, idioma_libro, numero_paginas, codigo_editorial FROM Libro WHERE ISBN = '" + ISBN + "'";
        try{
            System.out.println("consultando en la bd");
            Connection conn = fachada.openConnection();
            Statement sentencia = conn.createStatement();
            ResultSet tabla = sentencia.executeQuery(sql_select);

            while (tabla.next()){
                libro.setISBN(tabla.getString(1));
                libro.setTituloLibro(tabla.getString(2));
                libro.setAnhoPublicacion(tabla.getString(3));
                libro.setIdiomaLibro(tabla.getString(4));
                libro.setNumeroPaginas(tabla.getString(5));
                libro.setCodigoEditorial(tabla.getString(6));
            }

            conn.close();
            System.out.println("Conexion Cerrada");

        }
        catch(SQLException e){ System.out.println(e); }
        catch(Exception e){ System.out.println(e); }
        return libro;
    }
    public void modificarLibro(Libro libro, String ISBN){
        String sql_update = "UPDATE Libro SET titulo_libro = '" +libro.getTituloLibro() + "' , anho_publicacion = '" + libro.getAnhoPublicacion() + "' , idioma_libro = '" +
                libro.getIdiomaLibro() + "' , numero_paginas = '" + libro.getNumeroPaginas() + "' , codigo_editorial = '" + libro.getCodigoEditorial() +
                "' WHERE ISBN = '" + ISBN + "'";
        try{
            Connection conn = fachada.openConnection();
            Statement sentencia = conn.createStatement();
            if (sentencia.executeUpdate(sql_update) > 0) JOptionPane.showMessageDialog(null,"Se actualizó correctamente");
        }
        catch(SQLException e){ System.out.println(e);}
        catch(Exception e){ System.out.println(e);}
    }
    public List listarLibros(){
        List<Libro> libroList = new ArrayList<>();
        PreparedStatement sentencia = null;
        String sql_list = "SELECT * FROM Libro";

        try{
            Connection conn = fachada.openConnection();
            sentencia = conn.prepareStatement(sql_list);
            ResultSet rs = sentencia.executeQuery();
            while(rs.next()){
                Libro libro = new Libro();
                libro.setISBN(rs.getString(1));
                libro.setTituloLibro(rs.getString(2));
                libro.setAnhoPublicacion(rs.getString(3));
                libro.setIdiomaLibro(rs.getString(4));
                libro.setNumeroPaginas(rs.getString(5));
                libro.setCodigoEditorial(rs.getString(6));
                libroList.add(libro);
            }
        }
        catch(SQLException e){ System.out.println(e); }
        catch(Exception e){ System.out.println(e); }

        return libroList;
    }

    public void borrarLibro(String ISBN){
        String sql_delete;
        sql_delete = "DELETE FROM Libro WHERE ISBN ='" + ISBN +  "'";

        try{
            Connection conn = fachada.openConnection();
            Statement sentencia = conn.createStatement();
            int filasafectadas = sentencia.executeUpdate(sql_delete);
            if(filasafectadas > 0) JOptionPane.showMessageDialog(null, "El registro se ha eliminado correctamente");
            else {System.out.println("El " + ISBN + "no existe en la base de datos");}
        }
        catch(SQLException e){ System.out.println(e); }
        catch(Exception e){ System.out.println(e); }
    }

    public void cerrarConexionBD(){
        fachada.closeConection(fachada.getConexion());
    }


}
