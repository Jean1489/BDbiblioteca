package accesoDatos;

import logica.Autor;
import logica.Estudiante;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DaoEstudiante {
    FachadaBD fachada;

    public DaoEstudiante(){
        fachada = new FachadaBD();
    }

    public int guardarEstudiante(Estudiante estudiante){
        String sql_guardar = "INSERT INTO Estudiante(id_estudiante,carrera,universidad) VALUES( '" + estudiante.getIdEstudiante() + "' , '"
                + estudiante.getCarrera() + "' , '" + estudiante.getUniversidad() + "')";
        try {
            Connection conn = fachada.openConnection();
            Statement sentencia = conn.createStatement();
            int numFilas = sentencia.executeUpdate(sql_guardar);
            conn.close();
            return numFilas;

        }
        catch (SQLException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null,"El Id ingresado ya existe");
        }
        catch (Exception e) {System.out.println(e);}

        return -1;
    }

    public Estudiante consultarEstudiante(String idEstudiante){
        Estudiante estudiante = new Estudiante();
        String sql_select;
        sql_select = "SELECT carrera, universidad FROM Estudiante WHERE id_estudiante = '" + idEstudiante + "'";

        try{
            System.out.println("consultando en la bd");
            Connection conn = fachada.openConnection();
            Statement sentencia = conn.createStatement();
            ResultSet tabla = sentencia.executeQuery(sql_select);

            while (tabla.next()){
                estudiante.setCarrera(tabla.getString(1));
                estudiante.setUniversidad(tabla.getString(2));
            }

            conn.close();
            System.out.println("Conexion Cerrada");

        }
        catch(SQLException e){ System.out.println(e); }
        catch(Exception e){ System.out.println(e); }
        return estudiante;
    }

    public void modificarEstudiante(Estudiante estudiante, String idEstudiante){
        String sql_update = "UPDATE Estudiante SET carrera = '" + estudiante.getCarrera() + "' , universidad = '" + estudiante.getUniversidad() + "' WHERE id_estudiante = '" + idEstudiante + "'";
        try{
            Connection conn = fachada.openConnection();
            Statement sentencia = conn.createStatement();
            if (sentencia.executeUpdate(sql_update) > 0) JOptionPane.showMessageDialog(null,"Se actualizó correctamente");
        }
        catch(SQLException e){ System.out.println(e);}
        catch(Exception e){ System.out.println(e);}
    }

    public List listarEstudiante(){
        List<Estudiante> estudiantes = new ArrayList<>();
        PreparedStatement sentencia = null;
        String sql_list = "SELECT * FROM Estudiante";

        try{
            Connection conn = fachada.openConnection();
            sentencia = conn.prepareStatement(sql_list);
            ResultSet rs = sentencia.executeQuery();
            while(rs.next()){
                Estudiante student = new Estudiante();
                student.setIdEstudiante(rs.getString(1));
                student.setCarrera(rs.getString(2));
                student.setUniversidad(rs.getString(3));
                estudiantes.add(student);
            }
        }
        catch(SQLException e){ System.out.println(e); }
        catch(Exception e){ System.out.println(e); }

        return estudiantes;
    }

    public void borrarEstudiante(String idEstudiante){
        String sql_delete;
        sql_delete = "DELETE FROM Estudiante WHERE id_estudiante ='" + idEstudiante +  "'";

        try{
            Connection conn = fachada.openConnection();
            Statement sentencia = conn.createStatement();
            int filasafectadas = sentencia.executeUpdate(sql_delete);
            if(filasafectadas > 0) JOptionPane.showMessageDialog(null, "El registro se ha eliminado correctamente");
            else {System.out.println("El " + idEstudiante + "no existe en la base de datos");}
        }
        catch(SQLException e){ System.out.println(e); }
        catch(Exception e){ System.out.println(e); }
    }

    public void cerrarConexionBD(){
        fachada.closeConection(fachada.getConexion());
    }
}
