package GUI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class VentanaInicio extends JFrame {

    private JPanel Inicio;
    private JButton usuariosButton;
    private JButton librosButton;
    private JButton prestamoLibroButton;
    private JButton solicitarLibroButton;
    private JButton multaLibroButton;
    private JButton descargarLibroButton;
    private JLabel signOff;

    public VentanaInicio(){
        super("Sistema Bibliotecario");
        setSize(550,550);
        setContentPane(Inicio);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        if(Login.tipoUsuario.equals("Estudiante") || Login.tipoUsuario.equals("Profesor")){
            usuariosButton.setVisible(false);
            multaLibroButton.setVisible(false);
            prestamoLibroButton.setVisible(false);
        } else if (Login.tipoUsuario.equals("Empleado")) {
            usuariosButton.setVisible(false);
        }

        usuariosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Usuarios usuarios = new Usuarios();
                usuarios.setVisible(true);
                dispose();
            }
        });

        solicitarLibroButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Solicitudes solicitudes = new Solicitudes();
                solicitudes.setVisible(true);
                dispose();
            }
        });

        librosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Libros libros = new Libros();
                libros.setVisible(true);
                dispose();
            }
        });

        signOff.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                JOptionPane.showMessageDialog(null,"Seguro deseas cerrar Sesión?");
                Login login = new Login();
                login.setVisible(true);
                dispose();
            }
        });


    }
}
