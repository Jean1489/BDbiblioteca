package GUI;

import controlador.ControladorEstudiante;
import controlador.ControladorUsuario;
import logica.Empleado;
import logica.Estudiante;
import logica.Usuario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class Estudiantes extends JFrame{
    private JPanel panelEstudiante;
    private JButton insertarButton;
    private JButton buscarButton;
    private JButton editarButton;
    private JButton eliminarButton;
    private JTable table1;
    private JTextField textId;
    private JTextField textCarrera;
    private JTextField textUniversidad;
    private JLabel Volver;
    private DefaultTableModel model = new DefaultTableModel(){
        @Override
        public boolean isCellEditable(int row, int column) {
            super.isCellEditable(row, column);
            return false;
        }
    };

    ControladorUsuario controladorUsuario = new ControladorUsuario();
    ControladorEstudiante controladorEstudiante = new ControladorEstudiante();

    public Estudiantes(){
        super("Estudiantes");
        setSize(550,550);
        setContentPane(panelEstudiante);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        controladorEstudiante = new ControladorEstudiante();
        controladorUsuario = new ControladorUsuario();
        Tabla();
        listar();

        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!textId.getText().equals("") && !textCarrera.getText().equals("") && !textUniversidad.getText().equals("")) {
                    try{
                        int id = Integer.parseInt(textId.getText());
                        Usuario user = controladorUsuario.consultarUsuario(textId.getText());
                        if(user.getNombreUsuario() != null){
                            if(user.getTipoUsuario().equals("Estudiante")){
                                controladorEstudiante.insertarEstudiante(textId.getText(),textCarrera.getText(),textUniversidad.getText());
                                limpiarGUI();
                                model.setRowCount(0);
                                listar();
                            }else {
                                JOptionPane.showMessageDialog(null, "El Id es diferente o no pertenece a este registro");
                                limpiarGUI();
                            }
                        }else {
                            JOptionPane.showMessageDialog(null,"El usuario debe crearse primero en la tabla Usuario");
                            limpiarGUI();
                        }
                    }catch (NumberFormatException exception) {
                        JOptionPane.showMessageDialog(null,"El Id debe ser un numero entero");
                        limpiarGUI();
                    }
                }

            }
        });


        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textId.getText().equals("")){
                    Estudiante estudiante = controladorEstudiante.consultarEstudiante(textId.getText());
                    if(estudiante.getUniversidad() != null){
                        textCarrera.setText(estudiante.getCarrera());
                        textUniversidad.setText(estudiante.getUniversidad());
                    }else JOptionPane.showMessageDialog(null,"El Id ingresado no existe");
                } else JOptionPane.showMessageDialog(null,"Debes ingresar un Id para poder realizar la operación");

            }
        });


        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!textId.getText().equals("") && !textCarrera.getText().equals("") && !textUniversidad.getText().equals("")){
                    try{
                        int id = Integer.parseInt(textId.getText());
                        Estudiante estudiante = controladorEstudiante.consultarEstudiante(textId.getText());
                        if(estudiante != null){
                            estudiante.setUniversidad(textUniversidad.getText());
                            estudiante.setCarrera(textCarrera.getText());
                            controladorEstudiante.modificarEstudiante(estudiante,textId.getText());
                            limpiarGUI();
                            model.setRowCount(0);
                            listar();
                        }
                    }catch (NumberFormatException numberFormatException){
                        JOptionPane.showMessageDialog(null,"Error de conversión" + numberFormatException);
                        limpiarGUI();
                    }
                }

            }
        });


        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textId.getText().equals("")){
                    controladorEstudiante.borrarEstudiante(textId.getText());
                    model.setRowCount(0);
                    listar();
                    int opc = JOptionPane.showConfirmDialog(null, "¿Desea Eliminar el registro de la Tabla Usuario?", "Mensaje de confirmación", JOptionPane.OK_CANCEL_OPTION);
                    if(opc == 0){
                        controladorUsuario.eliminarUsuario(textId.getText());
                    }
                }
            }
        });


        Volver.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Usuarios usuarios = new Usuarios();
                usuarios.setVisible(true);
                dispose();
            }
        });
    }

    public void listar(){
        model.setRowCount(0);
        List<Estudiante> estudianteList = controladorEstudiante.listarEstudiante();
        for(Estudiante estudiante: estudianteList){
            model.addRow(new Object[]{estudiante.getIdEstudiante(),estudiante.getCarrera(),estudiante.getUniversidad()});
        }
    }

    public void Tabla(){
        String[] titulo = new String[]{"Identificación","Carrera","Universidad"};
        model.setColumnIdentifiers(titulo);
        table1.setModel(model);
    }

    public void limpiarGUI(){
        textId.setText("");
        textUniversidad.setText("");
        textCarrera.setText("");
        textId.requestFocus();
    }
}
