package GUI;

import controlador.ControladorAreaConocimiento;
import controlador.ControladorProfesor;
import controlador.ControladorUsuario;
import logica.AreaConocimiento;
import logica.Profesor;
import logica.Usuario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.util.List;

public class Profesores extends JFrame{
    private JButton insertarButton;
    private JButton buscarButton;
    private JButton editarButton;
    private JButton eliminarButton;
    private JTable table1;
    private JTextField textId;
    private JTextField textDependencia;
    private JTextField textTitulo;
    private JComboBox comboBoxArea;
    private JLabel Volver;
    private JPanel panelProfesor;

    private static DefaultComboBoxModel<String> idArea = new DefaultComboBoxModel<>();

    ControladorProfesor controladorProfesor = new ControladorProfesor();
    ControladorUsuario controladorUsuario = new ControladorUsuario();
    ControladorAreaConocimiento controladorAreaConocimiento = new ControladorAreaConocimiento();

    private DefaultTableModel model = new DefaultTableModel(){
        @Override
        public boolean isCellEditable(int row, int column) {
            super.isCellEditable(row, column);
            return false;
        }
    };

    public Profesores(){
        super("Profesores");
        setSize(550,550);
        setContentPane(panelProfesor);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        controladorProfesor = new ControladorProfesor();
        controladorUsuario = new ControladorUsuario();
        controladorAreaConocimiento = new ControladorAreaConocimiento();
        idArea.addElement("");
        Tabla();
        listar();
        insertarDatosJcomboBox(comboBoxArea);

        textId.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                super.keyReleased(e);
                if(!textId.getText().equals("")){
                    model.setRowCount(0);
                    for(Profesor profesor: controladorProfesor.listarProfesores()){
                        String cadena = profesor.getIdProfesor();
                        int posicion = cadena.indexOf(textId.getText());
                        if(posicion != -1){
                            model.addRow(new Object[]{profesor.getIdProfesor(),profesor.getDependencia(),profesor.getTitulo(),profesor.getArea_estudio()});
                        }
                    }
                }else{
                    model.setRowCount(0);
                    listar();
                }
            }
        });

        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textId.getText().equals("") && !textDependencia.getText().equals("") && !textTitulo.getText().equals("") &&
                !comboBoxArea.getSelectedItem().equals("")){
                    try{
                        int id = Integer.parseInt(textId.getText());
                        Usuario user = controladorUsuario.consultarUsuario(textId.getText());
                        if(user.getNombreUsuario() != null){
                            if(user.getTipoUsuario().equals("Profesor")){
                               controladorProfesor.insertarProfesor(textId.getText(),textDependencia.getText(),textTitulo.getText(),comboBoxArea.getSelectedItem().toString());
                                limpiarGUI();
                                model.setRowCount(0);
                                listar();
                            }else {
                                JOptionPane.showMessageDialog(null, "El Id es diferente o no pertenece a este registro");
                                limpiarGUI();
                            }
                        }else {
                            JOptionPane.showMessageDialog(null,"El usuario debe crearse primero en la tabla Usuario");
                            limpiarGUI();
                        }
                    }catch (NumberFormatException numberFormatException) {
                        JOptionPane.showMessageDialog(null, "El Id debe ser un numero entero. Error: " + numberFormatException);
                    }
                }
            }
        });

        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textId.getText().equals("")){
                    Profesor profesor = controladorProfesor.consultarProfesor(textId.getText());
                    if(profesor.getTitulo() != null){
                        textTitulo.setText(profesor.getTitulo());
                        textDependencia.setText(profesor.getDependencia());
                        comboBoxArea.setSelectedItem(profesor.getArea_estudio());

                    }else JOptionPane.showMessageDialog(null,"El Id ingresado no existe");
                }else JOptionPane.showMessageDialog(null,"Debes ingresar un Id para poder realizar la operación");
            }
        });

        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textId.getText().equals("") && !textDependencia.getText().equals("") && !textTitulo.getText().equals("") &&
                        !comboBoxArea.getSelectedItem().equals("")){
                    try{
                        Long id = Long.parseLong(textId.getText());
                        System.out.println(id);
                        Profesor profesor = controladorProfesor.consultarProfesor(String.valueOf(id));
                        if(profesor != null){
                            profesor.setTitulo(textTitulo.getText());
                            profesor.setDependencia(textDependencia.getText());
                            profesor.setArea_estudio(comboBoxArea.getSelectedItem().toString());
                            controladorProfesor.modificarProfesor(profesor,textId.getText());
                            limpiarGUI();
                            model.setRowCount(0);
                            listar();
                        }

                    }catch (NumberFormatException numberFormatException) {
                        JOptionPane.showMessageDialog(null,"Error de conversión" + numberFormatException);
                        limpiarGUI();
                    }
                }

            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textId.getText().equals("")){
                    controladorProfesor.borrarProfesor(textId.getText());
                    model.setRowCount(0);
                    listar();
                    int opc = JOptionPane.showConfirmDialog(null, "¿Desea Eliminar el registro de la Tabla Usuario?", "Mensaje de confirmación", JOptionPane.OK_CANCEL_OPTION);
                    if(opc == 0){
                        controladorUsuario.eliminarUsuario(textId.getText());
                    }
                }
            }
        });


        Volver.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Usuarios usuarios = new Usuarios();
                usuarios.setVisible(true);
                dispose();
            }
        });
    }

    public void Tabla(){
        String[] titulo = new String[]{"Identificación","Dependencia","Titulo","Área de Estudio"};
        model.setColumnIdentifiers(titulo);
        table1.setModel(model);
    }

    public void listar(){
        model.setRowCount(0);
        List<Profesor> profesorList = controladorProfesor.listarProfesores();
        for(Profesor profesor: profesorList){
            model.addRow(new Object[]{profesor.getIdProfesor(),profesor.getDependencia(),profesor.getTitulo(),profesor.getArea_estudio()});
        }
    }

    public void insertarDatosJcomboBox(JComboBox<String> jComboBox){
        List<AreaConocimiento> areaConocimientoList = controladorAreaConocimiento.listarAreaConocimiento();
        for(AreaConocimiento area: areaConocimientoList){
            String id = area.getCodigo_area();
            idArea.addElement(id);
        }jComboBox.setModel(idArea);
    }

    public void limpiarGUI(){
        textId.setText("");
        textDependencia.setText("");
        textTitulo.setText("");
        comboBoxArea.setSelectedItem("");
        textId.requestFocus();
    }
}
