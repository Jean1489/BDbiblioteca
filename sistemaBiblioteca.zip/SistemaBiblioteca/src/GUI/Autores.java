package GUI;

import controlador.ControladorAutor;
import logica.Autor;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class Autores extends JFrame {

    private JPanel panelAutores;
    private JButton insertarButton;
    private JButton buscarButton;
    private JButton editarButton;
    private JButton eliminarButton;
    private JTable table1;
    private JTextField textId;
    private JTextField textNombre1;
    private JTextField textNombre2;
    private JTextField textApellido1;
    private JTextField textApellido2;
    private JLabel Volver;
    private ControladorAutor controladorAutor = new ControladorAutor();
    private DefaultTableModel model = new DefaultTableModel(){
        @Override
        public boolean isCellEditable(int row, int column) {
            super.isCellEditable(row, column);
            return false;
        }
    };

    public Autores(){
        super("Autores");
        setSize(550,550);
        setContentPane(panelAutores);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        controladorAutor = new ControladorAutor();
        Tabla();
        listar();

        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textId.getText().equals("") && !textNombre1.getText().equals("") && !textNombre2.getText().equals("") && !textApellido1.getText().equals("")
                && !textApellido2.getText().equals("")){
                    Autor autor = controladorAutor.consultarAutor(textId.getText());
                    if(autor != null){
                        controladorAutor.insertarAutor(textId.getText(),textApellido1.getText(),textApellido2.getText(),textNombre1.getText(),textNombre2.getText());
                        model.setRowCount(0);
                        listar();
                        textApellido2.setText("");
                        textId.setText("");
                        textApellido1.setText("");
                        textNombre1.setText("");
                        textNombre2.setText("");
                        textId.requestFocus();
                    }
                }

            }
        });

        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textId.getText().equals("")){
                    Autor autor = controladorAutor.consultarAutor(textId.getText());
                    if(autor != null){
                        textNombre1.setText(autor.getFirstName());
                        textNombre2.setText(autor.getSecondName());
                        textApellido1.setText(autor.getSurname());
                        textApellido2.setText(autor.getSecondSurname());

                    } else JOptionPane.showMessageDialog(null, "El Id ingresado no existe");
                }
            }
        });

        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

        Volver.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Autores autor = new Autores();
                autor.setVisible(false);
                dispose();
            }
        });

    }

    public void listar(){
        model.setRowCount(0);
        List<Autor> autorList = controladorAutor.listarAutor();
        for(Autor autor: autorList){
            model.addRow(new Object[]{autor.getCodigoAutor(),autor.getFirstName(),autor.getSecondName(),autor.getSurname(),autor.getSecondSurname()});
        }
    }

    public void Tabla(){
        String[] titulo = new String[]{"Identificación","Nombre 1", "Nombre 2","Apellido 1", "Apellido 2"};
        model.setColumnIdentifiers(titulo);
        table1.setModel(model);
    }
}
