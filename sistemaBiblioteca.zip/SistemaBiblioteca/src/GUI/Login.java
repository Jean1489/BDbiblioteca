package GUI;

import controlador.ControladorUsuario;
import logica.Usuario;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Login extends JFrame {
    private JTextField userName;
    private JPasswordField password;
    private JButton iniciarSesiónButton;
    private JPanel panel1;
    private JLabel Label1;

    public static String nombreUsuario = "";
    public static String tipoUsuario = "";

    ControladorUsuario controladorUsuario;

    public Login(){
        super("Inicio Sesión");
        setContentPane(panel1);
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                setSize(350, 350);
                setLocationRelativeTo(null);
                addWindowListener(new WindowAdapter() {
                    @Override
                    public void windowClosing(WindowEvent e) {
                        super.windowClosing(e);
                        int opc = JOptionPane.showConfirmDialog(null, "¿Desea salir?", "Mensaje de confirmación", JOptionPane.OK_CANCEL_OPTION);
                        if (opc == 0) {
                            System.exit(0);
                        }
                    }
                });
            }
        });
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        controladorUsuario = new ControladorUsuario();
         ImageIcon imageIcon = new ImageIcon(getClass().getResource("/login.png"));
         Label1.setIcon(imageIcon);
         Label1.setHorizontalAlignment(JLabel.CENTER);
         Label1.setHorizontalAlignment(JLabel.CENTER);

        iniciarSesiónButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = userName.getText();
                String pass =  String.valueOf(password.getPassword());
                try{
                    Usuario user = controladorUsuario.consultarUsuario(pass);
                    if(user != null){
                        if(user.getNombreUsuario().equals(nombre)){
                            JOptionPane.showMessageDialog(null,"Bienvenido");
                            nombreUsuario = userName.getText();
                            tipoUsuario = user.getTipoUsuario();
                            System.out.println(tipoUsuario);
                            VentanaInicio inicio = new VentanaInicio();
                            inicio.setVisible(true);
                            dispose();
                        } else JOptionPane.showMessageDialog(null,"Usuario o contraseña incorrecta");
                    }
                } catch (Exception exception){
                    JOptionPane.showMessageDialog(null,"El Usuario: " + nombre + " no existe en la BD");
                    System.out.println("Error al consultar la base de datos");

                }
            }
        });
    }


    public static void main(String[] args) {
        Login login = new Login();
        login.setVisible(true);
    }
}
