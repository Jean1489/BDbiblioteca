package GUI;

import controlador.ControladorEmpleado;
import controlador.ControladorUsuario;
import logica.Empleado;
import logica.Usuario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class Empleados extends JFrame{
    private JPanel panelEmpleados;
    private JButton insertarButton;
    private JButton buscarButton;
    private JButton editarButton;
    private JButton eliminarButton;
    private JTextField textId;
    private JTextField textNombre;
    private JComboBox comboBoxcargo;
    private JTable table1;
    private JLabel Volver;
    private DefaultTableModel model = new DefaultTableModel(){
        @Override
        public boolean isCellEditable(int row, int column) {
            super.isCellEditable(row, column);
            return false;
        }
    };

    ControladorEmpleado controladorEmpleado = new ControladorEmpleado();
    ControladorUsuario controladorUsuario = new ControladorUsuario();

    public Empleados(){
        super("Empleados");
        setSize(550,550);
        setContentPane(panelEmpleados);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        controladorEmpleado = new ControladorEmpleado();
        controladorUsuario = new ControladorUsuario();
        Tabla();
        listar();

        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textId.getText().equals("") && !textNombre.getText().equals("") && !comboBoxcargo.getSelectedItem().equals("")){
                    try{
                        int id = Integer.parseInt(textId.getText());
                        Usuario user = controladorUsuario.consultarUsuario(textId.getText());
                        if(user.getIdUsuario() != null){
                            if(user.getNombreUsuario().equals(textNombre.getText()) && user.getTipoUsuario().equals("Empleado")){
                                controladorEmpleado.insertarEmpleado(textId.getText(),textNombre.getText(),comboBoxcargo.getSelectedItem().toString());
                                model.setRowCount(0);
                                listar();
                            }else JOptionPane.showMessageDialog(null, "El nombre del usuario es diferente o no pertenece a este registro");
                        }else JOptionPane.showMessageDialog(null,"El usuario debe crearse primero en la tabla Usuario");
                    }catch (NumberFormatException exception){

                    }
                }
            }
        });

        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textId.getText().equals("")){
                    Empleado empleado = controladorEmpleado.consultarEmpleado(textId.getText());
                    textNombre.setText(empleado.getNombre());
                    comboBoxcargo.setSelectedItem(empleado.getCargo());
                }
            }
        });

        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textId.getText().equals("") && !textNombre.getText().equals("") && !comboBoxcargo.getSelectedItem().equals("")){
                    try{
                        int number = Integer.parseInt(textId.getText());
                        Empleado empleado = controladorEmpleado.consultarEmpleado(textId.getText());
                        if(empleado != null){
                            empleado.setCargo(comboBoxcargo.getSelectedItem().toString());
                            controladorEmpleado.modificarEmpleado(empleado,textId.getText());
                            model.setRowCount(0);
                            listar();
                        }
                    }catch (NumberFormatException exception){
                        JOptionPane.showMessageDialog(null,"La identificacion es un número");
                    }
                }
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textId.getText().equals("")){
                    controladorEmpleado.borrarEmpleado(textId.getText());
                    model.setRowCount(0);
                    listar();
                    int opc = JOptionPane.showConfirmDialog(null, "¿Desea Eliminar el registro de la Tabla Usuario?", "Mensaje de confirmación", JOptionPane.OK_CANCEL_OPTION);
                    if(opc == 0){
                        controladorUsuario.eliminarUsuario(textId.getText());
                    }
                }
            }
        });

        Volver.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Usuarios usuarios = new Usuarios();
                usuarios.setVisible(true);
                dispose();
            }
        });
    }

    public void listar(){
        model.setRowCount(0);
        List<Empleado> empleadosList = controladorEmpleado.empleadoList();
        for(Empleado empleado: empleadosList){
            model.addRow(new Object[]{empleado.getIdEmpleado(),empleado.getNombre(),empleado.getCargo()});
        }
    }

    public void Tabla(){
        String[] titulo = new String[]{"Identificación","Nombre","Cargo"};
        model.setColumnIdentifiers(titulo);
        table1.setModel(model);
    }
}
