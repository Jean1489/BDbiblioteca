package GUI;

import controlador.ControladorEditorial;
import controlador.ControladorLibro;
import controlador.ControladorSolicitudLibro;
import logica.Editorial;
import logica.Libro;
import logica.SolicitudLibro;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.util.List;

public class Libros extends JFrame {

    private JPanel paneLibro;
    private JButton insertarButton;
    private JButton buscarButton;
    private JButton editarButton;
    private JButton eliminarButton;
    private JTable table1;
    private JLabel Volver;
    private JComboBox comboBoxEditorial;
    private JTextField textIdioma;
    private JTextField textNoPag;
    private JTextField textISBN;
    private JTextField textTitulo;
    private JTextField textAnho;
    private JButton autorButton;
    private JButton editorialButton;
    private JButton button3;
    private JButton button4;
    private ControladorLibro controladorLibro = new ControladorLibro();
    private ControladorEditorial controladorEditorial = new ControladorEditorial();
    private ControladorSolicitudLibro controladorSolicitudLibro = new ControladorSolicitudLibro();
    private static DefaultComboBoxModel<String> idEditorial = new DefaultComboBoxModel<>();
    private DefaultTableModel model = new DefaultTableModel(){
        @Override
        public boolean isCellEditable(int row, int column) {
            super.isCellEditable(row, column);
            return false;
        }
    };

    public Libros(){
        super("Libros");
        setSize(750,750);
        setContentPane(paneLibro);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        idEditorial.addElement("");
        controladorLibro = new ControladorLibro();
        controladorEditorial = new ControladorEditorial();
        controladorSolicitudLibro = new ControladorSolicitudLibro();
        Tabla();
        listar();
        insertarDatosJcomboBox(comboBoxEditorial);

        if(Login.tipoUsuario.equals("Estudiante") || Login.tipoUsuario.equals("Profesor")){
            insertarButton.setVisible(false);
            editarButton.setVisible(false);
            eliminarButton.setVisible(false);
            autorButton.setVisible(false);
            editorialButton.setVisible(false);
            button3.setVisible(false);
            button4.setVisible(false);
        }

        textTitulo.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                super.keyReleased(e);
                if(!textTitulo.getText().equals("")){
                    model.setRowCount(0);
                    for(Libro libro: controladorLibro.listarLibro()){
                        String cadena = libro.getTituloLibro();
                        int posicion = cadena.indexOf(textTitulo.getText());
                        if(posicion != -1){
                            model.addRow(new Object[]{libro.getISBN(),libro.getTituloLibro(),libro.getAnhoPublicacion(),libro.getIdiomaLibro(),libro.getNumeroPaginas(),libro.getCodigoEditorial()});
                        }
                    }
                } else{
                    model.setRowCount(0);
                    listar();
                }
            }
        });

        Volver.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                VentanaInicio ventanaInicio = new VentanaInicio();
                ventanaInicio.setVisible(true);
                dispose();
            }
        });

        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textISBN.getText().equals("") && !textTitulo.getText().equals("") && !textAnho.getText().equals("") &&
                !textIdioma.getText().equals("") && !textNoPag.getText().equals("") && !comboBoxEditorial.getSelectedItem().equals("")){
                    try{
                        int Anho = Integer.parseInt(textAnho.getText());
                        int noPag = Integer.parseInt(textNoPag.getText());
                        if(textISBN.getText().length() == 15){
                            Libro libro = controladorLibro.consultarLibro(textISBN.getText());
                            if(libro != null){
                                controladorLibro.insertarLibro(textISBN.getText(),textTitulo.getText(),textAnho.getText(),textNoPag.getText(),textIdioma.getText(),comboBoxEditorial.getSelectedItem().toString());
                                limpiarGUI();
                                model.setRowCount(0);
                                listar();
                            }else {
                                JOptionPane.showMessageDialog(null,"El ISBN ingresado ya existe en la base de datos");
                                limpiarGUI();
                                listar();
                            }
                        } else {
                            limpiarGUI();
                            listar();
                            JOptionPane.showMessageDialog(null,"Recuerda que la forma de un ISBN es: xxx-xxxxxxxxx-x");
                        }
                    }catch (NumberFormatException numberFormatException){
                        JOptionPane.showMessageDialog(null,"Verifique que los datos ingresados sean correctos");
                        limpiarGUI();
                        listar();
                    }

                }else JOptionPane.showMessageDialog(null,"Rellene los campos para poder realizar la operación");
            }
        });

        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textISBN.getText().equals("")){
                    Libro libro = controladorLibro.consultarLibro(textISBN.getText());
                    if(libro.getTituloLibro() != null){
                        textIdioma.setText(libro.getIdiomaLibro());
                        textNoPag.setText(libro.getNumeroPaginas());
                        textAnho.setText(libro.getAnhoPublicacion());
                        textTitulo.setText(libro.getTituloLibro());
                        comboBoxEditorial.setSelectedItem(libro.getCodigoEditorial());
                    }else {
                        JOptionPane.showMessageDialog(null,"El ISBN ingresado no existe");
                        limpiarGUI();
                    }
                }else JOptionPane.showMessageDialog(null,"Rellene el ISBN que desea buscar");
            }
        });

        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textISBN.getText().equals("") && !textTitulo.getText().equals("") && !textAnho.getText().equals("") &&  !textIdioma.getText().equals("") && !textNoPag.getText().equals("") && !comboBoxEditorial.getSelectedItem().equals("")){
                  try{
                      int Anho = Integer.parseInt(textAnho.getText());
                      int noPag = Integer.parseInt(textNoPag.getText());
                      if(textISBN.getText().length() == 15){
                          Libro libro = controladorLibro.consultarLibro(textISBN.getText());
                          if(libro.getTituloLibro() != null){
                              libro.setTituloLibro(textTitulo.getText());
                              libro.setAnhoPublicacion(textAnho.getText());
                              libro.setIdiomaLibro(textIdioma.getText());
                              libro.setNumeroPaginas(textNoPag.getText());
                              libro.setCodigoEditorial(comboBoxEditorial.getSelectedItem().toString());
                              System.out.println("Voy aqui");
                              controladorLibro.modificarLibro(libro,textISBN.getText());
                              limpiarGUI();
                              model.setRowCount(0);
                              listar();
                          }
                      }

                  }catch (NumberFormatException numberFormatException){
                      JOptionPane.showMessageDialog(null,"Verifique que los datos ingresados sean correctos");
                  }
                }

            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textISBN.getText().equals("")){
                    controladorLibro.eliminarLibro(textISBN.getText());
                    model.setRowCount(0);
                    listar();
                }
            }
        });

        autorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Autores autores = new Autores();
                autores.setVisible(true);
            }
        });

    }

    public void Tabla(){
        String[] titulo = new String[]{"ISBN","Titulo","Año","Idioma","No. Paginas","Id Editorial"};
        model.setColumnIdentifiers(titulo);
        table1.setModel(model);
    }

    public void listar(){
        model.setRowCount(0);
        List<Libro> libroList = controladorLibro.listarLibro();
        for(Libro libro: libroList){
            model.addRow(new Object[]{libro.getISBN(),libro.getTituloLibro(),libro.getAnhoPublicacion(),libro.getIdiomaLibro(),libro.getNumeroPaginas(),libro.getCodigoEditorial()});
        }
    }

    public void insertarDatosJcomboBox(JComboBox<String> jComboBox){
        List<Editorial> editorialList = controladorEditorial.listarEditorial();
        for(Editorial editorial: editorialList){
            String id = editorial.getCodigoEditorial();
            idEditorial.addElement(id);
        }jComboBox.setModel(idEditorial);
    }

    public void limpiarGUI(){
        textISBN.setText("");
        textTitulo.setText("");
        textAnho.setText("");
        textIdioma.setText("");
        textNoPag.setText("");
        comboBoxEditorial.setSelectedItem("");
        textISBN.requestFocus();
    }


}
