package GUI;

import controlador.ControladorLibro;
import controlador.ControladorSolicitudLibro;
import controlador.ControladorUsuario;
import logica.Libro;
import logica.SolicitudLibro;
import logica.Usuario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

public class Solicitudes extends JFrame{
    private JButton insertarButton;
    private JButton buscarButton;
    private JButton editarButton;
    private JButton eliminarButton;
    private JTable table1;
    private JTextField textidUsuario;
    private JTextField textISBN;
    private JTextField textNombre;
    private JLabel fechaSolicitud;
    private JTextPane descripcionSolicitud;
    private JPanel solicitudes;
    private JLabel regresar;
    private JTextField textidSolicitud;

    ControladorSolicitudLibro solicitud = new ControladorSolicitudLibro();
    ControladorUsuario usuario = new ControladorUsuario();
    ControladorLibro libro = new ControladorLibro();

    private DefaultTableModel model = new DefaultTableModel(){
        @Override
        public boolean isCellEditable(int row, int column) {
            super.isCellEditable(row, column);
            return false;
        }
    };

    public Solicitudes(){
        super("Solicitud Libros");
        setSize(600,600);
        setContentPane(solicitudes);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        solicitud = new ControladorSolicitudLibro();
        usuario = new ControladorUsuario();
        libro = new ControladorLibro();
        Tabla();
        listar();
        mostrarFecha();

        if(Login.tipoUsuario.equals("Estudiante")){
            buscarButton.setVisible(false);
            editarButton.setVisible(false);
            eliminarButton.setVisible(false);
        }

        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textidUsuario.getText().equals("") && !textNombre.getText().equals("") && !textISBN.getText().equals("")
                && !descripcionSolicitud.getText().equals("")){
                    if(textISBN.getText().length() == 15){
                        System.out.println("Funciona");
                        Usuario user = usuario.consultarUsuario(textidUsuario.getText());
                        Libro book = libro.consultarLibro(textISBN.getText());
                        if(user != null ){
                            if(book.getTituloLibro() == null){
                                DateFormat date = new SimpleDateFormat("dd/MM/yyyy");
                                try {
                                    Date Fecha = date.parse(fechaSolicitud.getText());
                                    solicitud.insertarSolicitudLibro(Fecha,descripcionSolicitud.getText(),textidUsuario.getText(),textISBN.getText(),textNombre.getText());
                                    model.setRowCount(0);
                                    listar();
                                    textidUsuario.setText("");
                                    textNombre.setText("");
                                    textISBN.setText("");
                                    descripcionSolicitud.setText("");
                                    textidUsuario.requestFocus();
                                } catch (ParseException ex) {
                                    throw new RuntimeException(ex);
                                }
                            }else JOptionPane.showMessageDialog(null, "El libro si esta en la base de datos" + book.getTituloLibro());
                        }else JOptionPane.showMessageDialog(null, "El Id usuario no esta registado en la base de datos");

                    }else JOptionPane.showMessageDialog(null,"El ISBN no tiene la cantidad de dígitos necesarios \n El ISBN tiene forma: xxx-xxxxxxxxx-x");
                }
            }
        });

        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textidSolicitud.getText().equals("")){
                    SolicitudLibro solicitudLibro = solicitud.consultar(textidSolicitud.getText());
                    if(solicitudLibro != null){
                        textidUsuario.setText(solicitudLibro.getIdUsuario());
                        textISBN.setText(solicitudLibro.getISBN());
                        textNombre.setText(solicitudLibro.getNombreLibro());
                        descripcionSolicitud.setText(solicitudLibro.getDescripcion());
                    } else JOptionPane.showMessageDialog(null, "El Id Solicitud buscado no existe en la base de datos");
                } else JOptionPane.showMessageDialog(null,"Ingresa el Id Solicitud para poder realizar la operación");

            }
        });

        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textidUsuario.getText().equals("") && !textNombre.getText().equals("") && !textISBN.getText().equals("")
                        && !descripcionSolicitud.getText().equals("") && !textidSolicitud.getText().equals("")){
                    SolicitudLibro solicitudLibro = solicitud.consultar(textidSolicitud.getText());
                    if(solicitudLibro != null){
                        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy"); //Output
                        try{
                           java.util.Date date = format.parse(fechaSolicitud.getText());
                            java.sql.Date sql = new java.sql.Date(date.getTime());
                            solicitudLibro.setFecha(sql);
                            Usuario user = usuario.consultarUsuario(textidUsuario.getText());
                            if(user != null){
                                solicitudLibro.setIdUsuario(user.getIdUsuario());
                                solicitudLibro.setISBN(textISBN.getText());
                                solicitudLibro.setDescripcion(descripcionSolicitud.getText());
                                solicitudLibro.setNombreLibro(textNombre.getText());
                                solicitud.modificarSolicitud(solicitudLibro,textidSolicitud.getText());
                                model.setRowCount(0);
                                listar();
                                textidSolicitud.setText("");
                                textidUsuario.setText("");
                                textNombre.setText("");
                                textISBN.setText("");
                                descripcionSolicitud.setText("");
                                textidUsuario.requestFocus();
                            }
                        }catch (ParseException ex) {
                            throw new RuntimeException(ex);
                        }
                    }
                }
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!textidSolicitud.getText().equals("")){
                    if(solicitud.consultar(textidSolicitud.getText()) != null){
                        solicitud.eliminarSolicitud(textidSolicitud.getText());
                        model.setRowCount(0);
                        listar();
                        textidSolicitud.setText("");
                        textidUsuario.requestFocus();
                    }
                }

            }
        });


        regresar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                VentanaInicio ventanaInicio = new VentanaInicio();
                ventanaInicio.setVisible(true);
                dispose();
            }
        });
    }

    public void Tabla(){
        String[] titulo = new String[]{"Identificación","Fecha","Descripción","Id_Usuario","ISBN","Nombre Libro"};
        model.setColumnIdentifiers(titulo);
        table1.setModel(model);
    }

    public void listar(){
        model.setRowCount(0);
        List<SolicitudLibro> solicitudLibros = solicitud.listarSolicitudLibro();
        for(SolicitudLibro solicitudLibro: solicitudLibros){
            model.addRow(new Object[]{solicitudLibro.getNumeroConsecutivo(),solicitudLibro.getFecha(),solicitudLibro.getDescripcion(),solicitudLibro.getIdUsuario(),solicitudLibro.getISBN(),solicitudLibro.getNombreLibro()});
        }
    }

    public void mostrarFecha(){
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaActual = new Date();
        String fechaFormateada = dateFormat.format(fechaActual);
        fechaSolicitud.setText(fechaFormateada);
    }
}
