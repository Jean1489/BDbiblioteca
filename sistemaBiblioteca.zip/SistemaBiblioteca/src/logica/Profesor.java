package logica;

public class Profesor {

    String idProfesor;
    String dependencia;
    String titulo;
    String area_estudio;

    public String getIdProfesor() {
        return idProfesor;
    }

    public void setIdProfesor(String idProfesor) {
        this.idProfesor = idProfesor;
    }

    public String getDependencia() {
        return dependencia;
    }

    public void setDependencia(String dependencia) {
        this.dependencia = dependencia;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getArea_estudio() {
        return area_estudio;
    }

    public void setArea_estudio(String area_estudio) {
        this.area_estudio = area_estudio;
    }
}
