/*BASE DE DATOS DE LA BIBLIOTECA
 Diseño e implementación del patrón DAO
   Autores: Yhan Carlos Trujillo Código: 202026415
            Andres Felipe Lopez Rodriguez: 2128542
            Mike García Guzmán: 2181021
*/
package logica;

import java.util.Date;

public class SolicitudLibro {
    int numeroConsecutivo;
    Date fecha;
    String descripcion;
    String idUsuario;
    String ISBN;
    String nombreLibro;

    public SolicitudLibro(){}

    public int getNumeroConsecutivo(){
        return numeroConsecutivo;
    }
    public void setNumeroConsecutivo(int numeroConsecutivo){
        this.numeroConsecutivo = numeroConsecutivo;
    }
    public Date getFecha(){
        return fecha;
    }
    public void setFecha(Date fecha){
        this.fecha = fecha;
    }
    public String getDescripcion(){
        return descripcion;
    }
    public void setDescripcion(String descripcion){
        this.descripcion = descripcion;
    }
    public String getIdUsuario(){
        return idUsuario;
    }
    public void setIdUsuario(String idUsuario){
        this.idUsuario = idUsuario;
    }
    public String getISBN(){
        return ISBN;
    }
    public void setISBN(String ISBN){
        this.ISBN = ISBN;
    }
    public String getNombreLibro(){
        return nombreLibro;
    }
    public void setNombreLibro(String nombreLibro){
        this.nombreLibro = nombreLibro;
    }
}
