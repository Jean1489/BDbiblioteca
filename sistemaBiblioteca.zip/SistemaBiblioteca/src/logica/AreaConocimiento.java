/*BASE DE DATOS DE LA BIBLIOTECA
 Diseño e implementación del patrón DAO
   Autores: Yhan Carlos Trujillo Código: 202026415
            Andres Felipe Lopez Rodriguez: 2128542
            Mike García Guzmán: 2181021
*/
package logica;

public class AreaConocimiento {
    String codigo_area;
    String nombre_area;
    String descripcion;
    String codigo_areaPadre;

    public String getCodigo_area() {
        return codigo_area;
    }

    public void setCodigo_area(String codigo_area) {
        this.codigo_area = codigo_area;
    }

    public String getNombre_area() {
        return nombre_area;
    }

    public void setNombre_area(String nombre_area) {
        this.nombre_area = nombre_area;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCodigo_areaPadre() {
        return codigo_areaPadre;
    }

    public void setCodigo_areaPadre(String codigo_areaPadre) {
        this.codigo_areaPadre = codigo_areaPadre;
    }
}
