package controlador;

import accesoDatos.DaoProfesor;
import logica.Estudiante;
import logica.Profesor;

import java.util.List;

public class ControladorProfesor {
    DaoProfesor daoProfesor;

    public ControladorProfesor(){
        daoProfesor = new DaoProfesor();
    }

    public int insertarProfesor(String idProfesor, String dependencias, String titulo, String areas){
        Profesor profesor = new Profesor();
        profesor.setIdProfesor(idProfesor);
        profesor.setDependencia(dependencias);
        profesor.setTitulo(titulo);
        profesor.setArea_estudio(areas);

        int resultado = daoProfesor.insertarProfesor(profesor);
        return resultado;
    }
    public Profesor consultarProfesor(String idProfesor){
        Profesor profesor = daoProfesor.consultarProfesor(idProfesor);
        return profesor;
    }
    public void modificarProfesor(Profesor profesor, String idProfesor){
        daoProfesor.modificarProfesor(profesor,idProfesor);
    }
    public void borrarProfesor(String idProfesor){daoProfesor.eliminarProfesor(idProfesor);}
    public List<Profesor> listarProfesores(){
        return this.daoProfesor.listarProfesores();
    }
}
