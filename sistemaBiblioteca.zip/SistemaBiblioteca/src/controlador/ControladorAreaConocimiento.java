
package controlador;

import accesoDatos.DaoAreaConocimiento;
import logica.AreaConocimiento;

import java.util.List;

public class ControladorAreaConocimiento {
    DaoAreaConocimiento daoAreaConocimiento;

    public ControladorAreaConocimiento(){
        daoAreaConocimiento = new DaoAreaConocimiento();
    }

    public int insertarAreaConocimiento(String codigo_area, String nombre_area, String descripcion, String areaPadre){
        AreaConocimiento areaConocimiento = new AreaConocimiento();
        areaConocimiento.setCodigo_area(codigo_area);
        areaConocimiento.setNombre_area(nombre_area);
        areaConocimiento.setDescripcion(descripcion);
        areaConocimiento.setCodigo_areaPadre(areaPadre);

        int result =  daoAreaConocimiento.guardarAreaConocimiento(areaConocimiento);
        return result;
    }

    public AreaConocimiento consultarAreaConocimiento(String codigo_area){
        AreaConocimiento areaConocimiento = daoAreaConocimiento.consultarAreaConocimiento(codigo_area);
        return areaConocimiento;
    }

    public void modificarAreaConocimiento(String codigo_area){
        daoAreaConocimiento.modificarAreaConocimiento(codigo_area);
    }

    public void eliminarAreaConocimiento(String codigo_area){
        daoAreaConocimiento.borrarAreaConocimiento(codigo_area);
    }

    public List <AreaConocimiento> listarAreaConocimiento(){
        List<AreaConocimiento> area = this.daoAreaConocimiento.listarAreaConocimiento();
        return area;

    }

    public void cerrarConecionBD(){
        daoAreaConocimiento.cerrarConexionBD();
    }
}
