package controlador;

import accesoDatos.DaoLibro;
import logica.Libro;

import java.util.List;

public class ControladorLibro {
    DaoLibro daoLibro;

    public ControladorLibro(){
        daoLibro = new DaoLibro();
    }

    public int insertarLibro(String ISBN, String titulo_libro, String anho, String idioma, String numeroPaginas, String codigoEditorial){
        Libro libro = new Libro();
        libro.setISBN(ISBN);
        libro.setTituloLibro(titulo_libro);
        libro.setAnhoPublicacion(anho);
        libro.setIdiomaLibro(idioma);
        libro.setNumeroPaginas(numeroPaginas);
        libro.setCodigoEditorial(codigoEditorial);

        int result = daoLibro.guardarLibro(libro);
        return result;

    }

    public Libro consultarLibro(String ISBN){
        Libro libro = daoLibro.consultarLibro(ISBN);
        return libro;
    }

    public void modificarLibro(Libro libro, String ISBN){
        daoLibro.modificarLibro(libro,ISBN);
    }

    public List<Libro> listarLibro(){
        List<Libro> libroList = daoLibro.listarLibros();
        return libroList;
    }

    public void eliminarLibro(String ISBN){
        daoLibro.borrarLibro(ISBN);
    }

    public void cerrarConexionBD(){
        daoLibro.cerrarConexionBD();
    }

}
