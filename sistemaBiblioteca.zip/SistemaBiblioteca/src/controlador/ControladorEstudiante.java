package controlador;

import accesoDatos.DaoEstudiante;
import logica.Estudiante;

import java.util.List;

public class ControladorEstudiante {
    DaoEstudiante daoEstudiante;

    public ControladorEstudiante(){
        daoEstudiante = new DaoEstudiante();
    }

    public int insertarEstudiante(String idEstudiante, String carrera, String universidad){
        Estudiante estudiante = new Estudiante();
        estudiante.setIdEstudiante(idEstudiante);
        estudiante.setCarrera(carrera);
        estudiante.setUniversidad(universidad);

        int resultado = daoEstudiante.guardarEstudiante(estudiante);
        return resultado;
    }
    public Estudiante consultarEstudiante(String idEstudiante){
        Estudiante estudiante = daoEstudiante.consultarEstudiante(idEstudiante);
        return estudiante;
    }
    public void modificarEstudiante(Estudiante estudiante, String idEstudiante){
        daoEstudiante.modificarEstudiante(estudiante,idEstudiante);
    }
    public void borrarEstudiante(String idEstudiante){
        daoEstudiante.borrarEstudiante(idEstudiante);
    }
    public List<Estudiante> listarEstudiante(){
        List<Estudiante> estudiantes = daoEstudiante.listarEstudiante();
        return estudiantes;
    }
}
