
package controlador;

import accesoDatos.DaoSolicitudLibro;
import logica.SolicitudLibro;

import java.util.Date;
import java.util.List;

public class ControladorSolicitudLibro {
    DaoSolicitudLibro daoSolicitudLibro;

    public ControladorSolicitudLibro(){
        daoSolicitudLibro = new DaoSolicitudLibro();
    }

    public int insertarSolicitudLibro(Date fecha_solicitud, String descripcionSolicitud, String id_usuario, String ISBN, String nombre_libro){
        SolicitudLibro solicitud = new SolicitudLibro();
        solicitud.setFecha(fecha_solicitud);
        solicitud.setDescripcion(descripcionSolicitud);
        solicitud.setIdUsuario(id_usuario);
        solicitud.setISBN(ISBN);
        solicitud.setNombreLibro(nombre_libro);

        int result = daoSolicitudLibro.guardarSolicitudLibro(solicitud);
        return result;
    }

    public SolicitudLibro consultar(String numeroConsecutivo){
        SolicitudLibro solicitudLibro = daoSolicitudLibro.consultarSolicitudLibro(numeroConsecutivo);
        return solicitudLibro;

    }

    public void modificarSolicitud(SolicitudLibro solicitudLibro,String numeroConsecutivo){
        daoSolicitudLibro.modificarSolicitudLibro(solicitudLibro,numeroConsecutivo);
    }

    public void eliminarSolicitud(String numeroConsecutivo){
        daoSolicitudLibro.borrarSolicitudLibro(numeroConsecutivo);
    }

    public List<SolicitudLibro> listarSolicitudLibro(){
        List<SolicitudLibro> solicitud = this.daoSolicitudLibro.listarSolicitudLibro();
        return solicitud;
    }

    public void cerrarConexionBD(){
        daoSolicitudLibro.cerrarConexionBD();
    }
}
