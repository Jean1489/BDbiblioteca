package controlador;

import accesoDatos.DaoEmpleado;
import logica.Empleado;

import java.util.List;

public class ControladorEmpleado {
    DaoEmpleado daoEmpleado;

    public ControladorEmpleado(){daoEmpleado = new DaoEmpleado();}

    public int insertarEmpleado(String idEmpleado, String nombre, String cargo){
        Empleado empleado = new Empleado();
        empleado.setIdEmpleado(idEmpleado);
        empleado.setNombre(nombre);
        empleado.setCargo(cargo);
        int result = daoEmpleado.insertarEmpleado(empleado);
        return result;
    }
    public List<Empleado> empleadoList(){
        return this.daoEmpleado.listarEmpleados();
    }
    public Empleado consultarEmpleado(String idEmpleado){
        return this.daoEmpleado.buscarEmpleado(idEmpleado);
    }
    public void modificarEmpleado(Empleado empleado, String idEmpleado){
        daoEmpleado.modificarEmpleado(empleado,idEmpleado);
    }
    public void borrarEmpleado(String idEmpleado){
        daoEmpleado.borrarEmpleado(idEmpleado);
    }
}
